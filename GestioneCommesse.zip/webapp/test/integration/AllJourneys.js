jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"gestionecommesse/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"gestionecommesse/test/integration/pages/Worklist",
		"gestionecommesse/test/integration/pages/Object",
		"gestionecommesse/test/integration/pages/NotFound",
		"gestionecommesse/test/integration/pages/Browser",
		"gestionecommesse/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "gestionecommesse.view."
	});

	sap.ui.require([
		"gestionecommesse/test/integration/WorklistJourney",
		"gestionecommesse/test/integration/ObjectJourney",
		"gestionecommesse/test/integration/NavigationJourney",
		"gestionecommesse/test/integration/NotFoundJourney",
		"gestionecommesse/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});